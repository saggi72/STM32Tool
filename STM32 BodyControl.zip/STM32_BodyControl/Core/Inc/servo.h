/**
 ******************************************************************************
 * @file    servo.h
 * @brief   Servo motor PWM driver for STM32F103
 *
 * Hardware mapping (5 channels):
 *   Servo1_HighLow   -> TIM2 CH1  PA0
 *   Servo2_Turn      -> TIM2 CH2  PA1
 *   Servo3_Wiper     -> TIM2 CH3  PA2
 *   Servo4_Washer    -> TIM2 CH4  PA3
 *   Servo5_Headlight -> TIM3 CH1  PA6
 *
 * PWM spec (standard hobby servo):
 *   Period   : 20 ms  (50 Hz)
 *   0 deg    : 500  us pulse  (CCR = 500)
 *   90 deg   : 1500 us pulse  (CCR = 1500)
 *   180 deg  : 2500 us pulse  (CCR = 2500)
 *
 * Timer config (72 MHz APB1 x2 = 72 MHz timer clock):
 *   Prescaler = 71  -> 1 MHz tick (1 us per count)
 *   ARR       = 19999 -> 20 ms period
 ******************************************************************************
 */

#ifndef SERVO_H
#define SERVO_H

#include <stdint.h>
#include "stm32f1xx_hal.h"

/* =========================================================================
 * Servo index
 * ========================================================================= */
typedef enum {
    SERVO_1_HIGHLOW    = 0,
    SERVO_2_TURN       = 1,
    SERVO_3_WIPER      = 2,
    SERVO_4_WASHER     = 3,
    SERVO_5_HEADLIGHT  = 4,
    SERVO_COUNT        = 5
} ServoIndex_t;

/* =========================================================================
 * PWM pulse width limits (microseconds = CCR value at 1MHz tick)
 * ========================================================================= */
#define SERVO_PULSE_MIN_US      500U    /* 0   degrees */
#define SERVO_PULSE_MID_US      1500U   /* 90  degrees */
#define SERVO_PULSE_MAX_US      2500U   /* 180 degrees */

/* =========================================================================
 * Predefined positions mapped to DBC signal values
 * ========================================================================= */

/* Servo1: HighLowBeam */
#define SERVO1_POS_OFF          0U
#define SERVO1_POS_LOWBEAM      90U
#define SERVO1_POS_HIGHBEAM     180U

/* Servo2: TurnSignal */
#define SERVO2_POS_OFF          90U
#define SERVO2_POS_LEFT         30U
#define SERVO2_POS_RIGHT        150U
#define SERVO2_POS_HAZARD       90U   /* center, both blink via software */

/* Servo3: WiperSpeed */
#define SERVO3_POS_OFF          0U
#define SERVO3_POS_INT1         36U
#define SERVO3_POS_INT2         72U
#define SERVO3_POS_LOW          108U
#define SERVO3_POS_HIGH         180U

/* Servo4: WiperWasher */
#define SERVO4_POS_OFF          0U
#define SERVO4_POS_ACTIVE       90U

/* Servo5: HeadlightMode */
#define SERVO5_POS_OFF          0U
#define SERVO5_POS_AUTO         60U
#define SERVO5_POS_FOG          120U
#define SERVO5_POS_FOLD         180U

/* =========================================================================
 * API
 * ========================================================================= */

/**
 * @brief  Initialize all servo PWM timers. Call after HAL_Init and
 *         SystemClock_Config but before the main loop.
 * @param  htim2  Pointer to TIM2 handle (CH1-CH4 for Servo 1-4)
 * @param  htim3  Pointer to TIM3 handle (CH1 for Servo 5)
 */
void Servo_Init(TIM_HandleTypeDef *htim2, TIM_HandleTypeDef *htim3);

/**
 * @brief  Set servo position in degrees (0-180).
 * @param  servo   ServoIndex_t
 * @param  degree  Target position 0~180 degrees
 */
void Servo_SetDegree(ServoIndex_t servo, uint8_t degree);

/**
 * @brief  Get current servo position in degrees.
 * @param  servo   ServoIndex_t
 * @retval Current degree 0~180
 */
uint8_t Servo_GetDegree(ServoIndex_t servo);

/**
 * @brief  Apply DBC signal values directly to servos.
 *         Maps each enum value to the correct physical position.
 */
void Servo_ApplyHighLowBeam(uint8_t cmd);
void Servo_ApplyTurnSignal(uint8_t cmd);
void Servo_ApplyWiperSpeed(uint8_t cmd);
void Servo_ApplyWiperWasher(uint8_t cmd);
void Servo_ApplyHeadlightMode(uint8_t cmd);

#endif /* SERVO_H */
