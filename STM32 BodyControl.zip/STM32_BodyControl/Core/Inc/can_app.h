/**
 ******************************************************************************
 * @file    can_app.h
 * @brief   CAN application layer for STM32F103 (bxCAN, HAL)
 *
 * Node    : STM32Tool (slave)
 * RX      : BCM_LightRainCmd  (0x320) from ControlECU
 * TX      : STM32_ServoStatus (0x325) to ControlECU, every 100ms
 ******************************************************************************
 */

#ifndef CAN_APP_H
#define CAN_APP_H

#include <stdint.h>
#include <stdbool.h>
#include "stm32f1xx_hal.h"
#include "can_dbc.h"

/**
 * @brief  Initialize CAN peripheral: filters, start CAN, activate RX interrupt.
 * @param  hcan  Pointer to CAN handle (CAN1)
 */
void CANApp_Init(CAN_HandleTypeDef *hcan);

/**
 * @brief  Call from HAL_CAN_RxFifo0MsgPendingCallback(). Reads the pending
 *         frame, decodes it if it matches BCM_LightRainCmd, and applies
 *         the commands to the servos immediately.
 */
void CANApp_RxFifo0Callback(CAN_HandleTypeDef *hcan);

/**
 * @brief  Periodic task - call from main loop or a 10ms/100ms scheduler tick.
 *         Handles cyclic TX of STM32_ServoStatus and RX timeout monitoring.
 *         Non-blocking; uses HAL_GetTick() internally.
 */
void CANApp_Task(void);

/**
 * @brief  Returns true if a valid BCM_LightRainCmd frame has been received
 *         within CAN_RX_TIMEOUT_MS. Use to detect bus-off / ECU silence.
 */
bool CANApp_IsRxAlive(void);

/**
 * @brief  Get the last decoded RX command struct (for diagnostics/UI).
 */
const BCM_LightRainCmd_t *CANApp_GetLastCmd(void);

#endif /* CAN_APP_H */
