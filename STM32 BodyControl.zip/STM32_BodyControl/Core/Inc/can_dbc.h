/**
 ******************************************************************************
 * @file    can_dbc.h
 * @brief   CAN signal/message definitions generated from BodyControlNetwork.dbc
 *
 * Network : VehicleBodyCAN
 * Baudrate : 500 kbps
 * Node     : STM32Tool (Slave)
 *
 * MSG RX  : BCM_LightRainCmd  ID=0x320  DLC=8  Cycle=50ms   (ControlECU -> STM32Tool)
 * MSG TX  : STM32_ServoStatus ID=0x325  DLC=8  Cycle=100ms  (STM32Tool  -> ControlECU)
 ******************************************************************************
 */

#ifndef CAN_DBC_H
#define CAN_DBC_H

#include <stdint.h>

/* =========================================================================
 * CAN Message IDs
 * ========================================================================= */
#define CAN_ID_BCM_LIGHTRAINCMD     (0x320U)   /* RX - from ControlECU */
#define CAN_ID_STM32_SERVOSTAT      (0x325U)   /* TX - from STM32Tool  */

/* =========================================================================
 * BCM_LightRainCmd  (RX, 0x320, DLC=8, 50ms)
 * Signal layout (Intel/Little-Endian, all unsigned):
 *   Byte 0 [1:0]  HighLowBeam_Cmd   2-bit  0=OFF 1=LowBeam 2=HighBeam
 *   Byte 0 [3:2]  TurnSignal_Cmd    2-bit  0=OFF 1=LEFT 2=RIGHT 3=HAZARD
 *   Byte 0 [4]    FlashLight_Cmd    1-bit  0=Normal 1=Flash
 *   Byte 0 [7:5]  WiperSpeed_Cmd    3-bit  0=OFF 1=INT1 2=INT2 3=LOW 4=HIGH
 *   Byte 1 [0]    WiperWasher_Cmd   1-bit  0=OFF 1=ACTIVE
 *   Byte 1 [2:1]  HeadlightMode_Cmd 2-bit  0=OFF 1=AUTO 2=FOG 3=FOLD
 * ========================================================================= */

/* Enum: HighLowBeam_Cmd */
typedef enum {
    HIGHLOWBEAM_OFF      = 0,
    HIGHLOWBEAM_LOW      = 1,
    HIGHLOWBEAM_HIGH     = 2
} HighLowBeam_Cmd_t;

/* Enum: TurnSignal_Cmd */
typedef enum {
    TURNSIGNAL_OFF       = 0,
    TURNSIGNAL_LEFT      = 1,
    TURNSIGNAL_RIGHT     = 2,
    TURNSIGNAL_HAZARD    = 3
} TurnSignal_Cmd_t;

/* Enum: FlashLight_Cmd */
typedef enum {
    FLASHLIGHT_NORMAL    = 0,
    FLASHLIGHT_FLASH     = 1
} FlashLight_Cmd_t;

/* Enum: WiperSpeed_Cmd */
typedef enum {
    WIPERSPEED_OFF       = 0,
    WIPERSPEED_INT1      = 1,
    WIPERSPEED_INT2      = 2,
    WIPERSPEED_LOW       = 3,
    WIPERSPEED_HIGH      = 4
} WiperSpeed_Cmd_t;

/* Enum: WiperWasher_Cmd */
typedef enum {
    WIPERWASHER_OFF      = 0,
    WIPERWASHER_ACTIVE   = 1
} WiperWasher_Cmd_t;

/* Enum: HeadlightMode_Cmd */
typedef enum {
    HEADLIGHTMODE_OFF    = 0,
    HEADLIGHTMODE_AUTO   = 1,
    HEADLIGHTMODE_FOG    = 2,
    HEADLIGHTMODE_FOLD   = 3
} HeadlightMode_Cmd_t;

/* Decoded RX message struct */
typedef struct {
    HighLowBeam_Cmd_t   HighLowBeam_Cmd;
    TurnSignal_Cmd_t    TurnSignal_Cmd;
    FlashLight_Cmd_t    FlashLight_Cmd;
    WiperSpeed_Cmd_t    WiperSpeed_Cmd;
    WiperWasher_Cmd_t   WiperWasher_Cmd;
    HeadlightMode_Cmd_t HeadlightMode_Cmd;
} BCM_LightRainCmd_t;

/* =========================================================================
 * STM32_ServoStatus  (TX, 0x325, DLC=8, 100ms)
 * Signal layout:
 *   Byte 0   Servo1_HighLow_Pos    8-bit  0~180 deg
 *   Byte 1   Servo2_Turn_Pos       8-bit  0~180 deg
 *   Byte 2   Servo3_Wiper_Pos      8-bit  0~180 deg
 *   Byte 3   Servo4_Washer_Pos     8-bit  0~180 deg
 *   Byte 4   Servo5_Headlight_Pos  8-bit  0~180 deg
 *   Byte 5-7 Reserved (0x00)
 * ========================================================================= */

typedef struct {
    uint8_t Servo1_HighLow_Pos;
    uint8_t Servo2_Turn_Pos;
    uint8_t Servo3_Wiper_Pos;
    uint8_t Servo4_Washer_Pos;
    uint8_t Servo5_Headlight_Pos;
} STM32_ServoStatus_t;

/* =========================================================================
 * Signal extraction macros  (from raw 8-byte CAN data[])
 * ========================================================================= */
#define DBC_GET_HIGHLOWBEAM(data)    ((HighLowBeam_Cmd_t)  (((data)[0] >> 0) & 0x03U))
#define DBC_GET_TURNSIGNAL(data)     ((TurnSignal_Cmd_t)   (((data)[0] >> 2) & 0x03U))
#define DBC_GET_FLASHLIGHT(data)     ((FlashLight_Cmd_t)   (((data)[0] >> 4) & 0x01U))
#define DBC_GET_WIPERSPEED(data)     ((WiperSpeed_Cmd_t)   (((data)[0] >> 5) & 0x07U))
#define DBC_GET_WIPERWASHER(data)    ((WiperWasher_Cmd_t)  (((data)[1] >> 0) & 0x01U))
#define DBC_GET_HEADLIGHTMODE(data)  ((HeadlightMode_Cmd_t)(((data)[1] >> 1) & 0x03U))

/* =========================================================================
 * TX message pack macro
 * ========================================================================= */
#define DBC_PACK_SERVOSTAT(buf, s1, s2, s3, s4, s5) \
    do {                                              \
        (buf)[0] = (uint8_t)(s1);                    \
        (buf)[1] = (uint8_t)(s2);                    \
        (buf)[2] = (uint8_t)(s3);                    \
        (buf)[3] = (uint8_t)(s4);                    \
        (buf)[4] = (uint8_t)(s5);                    \
        (buf)[5] = 0x00U;                            \
        (buf)[6] = 0x00U;                            \
        (buf)[7] = 0x00U;                            \
    } while(0)

/* =========================================================================
 * Cycle time constants (ms)
 * ========================================================================= */
#define CAN_CYCLE_BCM_LIGHTRAINCMD_MS   50U
#define CAN_CYCLE_SERVOSTAT_MS          100U

/* Timeout: if no RX within this period, treat as bus-off / ECU timeout */
#define CAN_RX_TIMEOUT_MS               200U

#endif /* CAN_DBC_H */
