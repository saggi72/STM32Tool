/**
 ******************************************************************************
 * @file    servo.c
 * @brief   Servo motor PWM driver implementation for STM32F103
 ******************************************************************************
 */

#include "servo.h"

/* =========================================================================
 * Private data
 * ========================================================================= */
static TIM_HandleTypeDef *s_htim2 = NULL;   /* Servo 1-4 */
static TIM_HandleTypeDef *s_htim3 = NULL;   /* Servo 5   */

static uint8_t s_currentDegree[SERVO_COUNT] = {0, 0, 0, 0, 0};

/* Map ServoIndex_t -> (timer handle, channel) */
typedef struct {
    TIM_HandleTypeDef **htim;
    uint32_t channel;
} ServoChannelMap_t;

/* Filled in Servo_Init() once handles are known */
static ServoChannelMap_t s_map[SERVO_COUNT];

/* =========================================================================
 * Private helpers
 * ========================================================================= */

/**
 * @brief  Convert 0-180 degree value to CCR pulse width (us).
 */
static uint16_t Servo_DegreeToPulse(uint8_t degree)
{
    if (degree > 180U) {
        degree = 180U;
    }

    /* Linear map: 0deg->500us, 180deg->2500us */
    uint32_t pulse = SERVO_PULSE_MIN_US +
        ((uint32_t)degree * (SERVO_PULSE_MAX_US - SERVO_PULSE_MIN_US)) / 180U;

    return (uint16_t)pulse;
}

/**
 * @brief  Write CCR register for a given servo channel.
 */
static void Servo_WritePulse(ServoIndex_t servo, uint16_t pulse_us)
{
    if (servo >= SERVO_COUNT || s_map[servo].htim == NULL || *s_map[servo].htim == NULL) {
        return;
    }
    __HAL_TIM_SET_COMPARE(*s_map[servo].htim, s_map[servo].channel, pulse_us);
}

/* =========================================================================
 * Public API
 * ========================================================================= */

void Servo_Init(TIM_HandleTypeDef *htim2, TIM_HandleTypeDef *htim3)
{
    s_htim2 = htim2;
    s_htim3 = htim3;

    /* Build channel map */
    s_map[SERVO_1_HIGHLOW].htim   = &s_htim2;
    s_map[SERVO_1_HIGHLOW].channel = TIM_CHANNEL_1;

    s_map[SERVO_2_TURN].htim      = &s_htim2;
    s_map[SERVO_2_TURN].channel   = TIM_CHANNEL_2;

    s_map[SERVO_3_WIPER].htim     = &s_htim2;
    s_map[SERVO_3_WIPER].channel  = TIM_CHANNEL_3;

    s_map[SERVO_4_WASHER].htim    = &s_htim2;
    s_map[SERVO_4_WASHER].channel = TIM_CHANNEL_4;

    s_map[SERVO_5_HEADLIGHT].htim    = &s_htim3;
    s_map[SERVO_5_HEADLIGHT].channel = TIM_CHANNEL_1;

    /* Start PWM on all channels */
    HAL_TIM_PWM_Start(s_htim2, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(s_htim2, TIM_CHANNEL_2);
    HAL_TIM_PWM_Start(s_htim2, TIM_CHANNEL_3);
    HAL_TIM_PWM_Start(s_htim2, TIM_CHANNEL_4);
    HAL_TIM_PWM_Start(s_htim3, TIM_CHANNEL_1);

    /* Default all servos to 0 degrees (safe / OFF position) */
    for (uint8_t i = 0; i < SERVO_COUNT; i++) {
        Servo_SetDegree((ServoIndex_t)i, 0);
    }
}

void Servo_SetDegree(ServoIndex_t servo, uint8_t degree)
{
    if (servo >= SERVO_COUNT) {
        return;
    }
    if (degree > 180U) {
        degree = 180U;
    }

    uint16_t pulse = Servo_DegreeToPulse(degree);
    Servo_WritePulse(servo, pulse);
    s_currentDegree[servo] = degree;
}

uint8_t Servo_GetDegree(ServoIndex_t servo)
{
    if (servo >= SERVO_COUNT) {
        return 0U;
    }
    return s_currentDegree[servo];
}

/* =========================================================================
 * DBC signal -> servo position mapping
 * ========================================================================= */

void Servo_ApplyHighLowBeam(uint8_t cmd)
{
    uint8_t degree;
    switch (cmd) {
        case 1: degree = SERVO1_POS_LOWBEAM;  break;
        case 2: degree = SERVO1_POS_HIGHBEAM; break;
        case 0:
        default: degree = SERVO1_POS_OFF; break;
    }
    Servo_SetDegree(SERVO_1_HIGHLOW, degree);
}

void Servo_ApplyTurnSignal(uint8_t cmd)
{
    uint8_t degree;
    switch (cmd) {
        case 1: degree = SERVO2_POS_LEFT;   break;
        case 2: degree = SERVO2_POS_RIGHT;  break;
        case 3: degree = SERVO2_POS_HAZARD; break;
        case 0:
        default: degree = SERVO2_POS_OFF; break;
    }
    Servo_SetDegree(SERVO_2_TURN, degree);
}

void Servo_ApplyWiperSpeed(uint8_t cmd)
{
    uint8_t degree;
    switch (cmd) {
        case 1: degree = SERVO3_POS_INT1; break;
        case 2: degree = SERVO3_POS_INT2; break;
        case 3: degree = SERVO3_POS_LOW;  break;
        case 4: degree = SERVO3_POS_HIGH; break;
        case 0:
        default: degree = SERVO3_POS_OFF; break;
    }
    Servo_SetDegree(SERVO_3_WIPER, degree);
}

void Servo_ApplyWiperWasher(uint8_t cmd)
{
    uint8_t degree = (cmd == 1) ? SERVO4_POS_ACTIVE : SERVO4_POS_OFF;
    Servo_SetDegree(SERVO_4_WASHER, degree);
}

void Servo_ApplyHeadlightMode(uint8_t cmd)
{
    uint8_t degree;
    switch (cmd) {
        case 1: degree = SERVO5_POS_AUTO; break;
        case 2: degree = SERVO5_POS_FOG;  break;
        case 3: degree = SERVO5_POS_FOLD; break;
        case 0:
        default: degree = SERVO5_POS_OFF; break;
    }
    Servo_SetDegree(SERVO_5_HEADLIGHT, degree);
}
