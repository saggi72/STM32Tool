/**
 ******************************************************************************
 * @file    main.c
 * @brief   STM32F103 Body Control slave node
 *
 * Hardware assumed:
 *   MCU        : STM32F103C8T6 (Blue Pill) or similar
 *   CAN        : CAN1, PA11=RX, PA12=TX, external transceiver (e.g. TJA1050)
 *   Servo PWM  : TIM2 CH1-4 (PA0-PA3), TIM3 CH1 (PA6)
 *   Clock      : HSE 8MHz -> PLL x9 -> 72MHz SYSCLK
 *
 * This file follows the STM32CubeMX-generated main.c structure so you can
 * paste the MX_*_Init() bodies into a CubeMX project, or use this as-is if
 * you're not using CubeMX (adjust startup/HAL includes as needed).
 *
 * CAN bit timing for 500 kbps @ 36MHz APB1 (CAN1 is on APB1):
 *   Prescaler = 4, TimeSeg1 = 8 (BS1=CAN_BS1_8TQ), TimeSeg2 = 1 (BS2_1TQ)... 
 *   -> Actual config below uses Prescaler=9, BS1=8TQ, BS2=1TQ =>
 *      Tq = 9/36MHz = 250ns, bit = (1+8+1)=10Tq = 2.5us => 400kbps -- WRONG.
 *   Use the values in MX_CAN_Init() below instead (Prescaler=4,
 *   BS1=CAN_BS1_15TQ, BS2=CAN_BS2_2TQ, 1+15+2=18Tq,
 *   36MHz/4=9MHz Tq clock, 9MHz/18=500kHz -> 500 kbps). Verify against
 *   your actual APB1 clock before flashing.
 ******************************************************************************
 */

#include "stm32f1xx_hal.h"
#include "can_app.h"
#include "servo.h"

/* =========================================================================
 * Peripheral handles
 * ========================================================================= */
CAN_HandleTypeDef  hcan1;
TIM_HandleTypeDef  htim2;
TIM_HandleTypeDef  htim3;

/* =========================================================================
 * Function prototypes
 * ========================================================================= */
static void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_CAN1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void Error_Handler(void);

/* =========================================================================
 * main
 * ========================================================================= */
int main(void)
{
    HAL_Init();
    SystemClock_Config();

    MX_GPIO_Init();
    MX_CAN1_Init();
    MX_TIM2_Init();
    MX_TIM3_Init();

    /* Bring up servo PWM outputs (defaults all to 0 deg / OFF position) */
    Servo_Init(&htim2, &htim3);

    /* Bring up CAN: filter for 0x320, start peripheral, enable RX IT */
    CANApp_Init(&hcan1);

    while (1)
    {
        /* Non-blocking: handles 100ms cyclic TX of STM32_ServoStatus (0x325)
         * and RX timeout monitoring. RX decode/apply happens in the
         * HAL_CAN_RxFifo0MsgPendingCallback ISR context via CANApp_RxFifo0Callback. */
        CANApp_Task();

        /* Insert other slow background tasks here (LED heartbeat, etc.) */
        HAL_Delay(1);
    }
}

/* =========================================================================
 * HAL CAN RX callback - forwards to application layer
 * ========================================================================= */
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
    CANApp_RxFifo0Callback(hcan);
}

/* =========================================================================
 * System Clock Configuration
 * HSE 8MHz -> PLLx9 -> 72MHz SYSCLK, APB1=36MHz, APB2=72MHz
 * ========================================================================= */
static void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState       = RCC_HSE_ON;
    RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
    RCC_OscInitStruct.PLL.PLLState   = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource  = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLMUL     = RCC_PLL_MUL9;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
        Error_Handler();
    }

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK   | RCC_CLOCKTYPE_SYSCLK |
                                  RCC_CLOCKTYPE_PCLK1  | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;   /* APB1 = 36 MHz (CAN1, TIM2/3 clock source before x2) */
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;   /* APB2 = 72 MHz */

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
    {
        Error_Handler();
    }
}

/* =========================================================================
 * GPIO Initialization
 * PA0-PA3 : TIM2 CH1-4 (Servo1-4 PWM, AF push-pull)
 * PA6     : TIM3 CH1   (Servo5 PWM, AF push-pull)
 * PA11/12 : CAN1 RX/TX (AF push-pull for TX, input for RX)
 * ========================================================================= */
static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_AFIO_CLK_ENABLE();

    /* TIM2 CH1-4: PA0, PA1, PA2, PA3 -> AF Push-Pull */
    GPIO_InitStruct.Pin   = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3;
    GPIO_InitStruct.Mode  = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* TIM3 CH1: PA6 -> AF Push-Pull */
    GPIO_InitStruct.Pin   = GPIO_PIN_6;
    GPIO_InitStruct.Mode  = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* CAN1 TX: PA12 -> AF Push-Pull */
    GPIO_InitStruct.Pin   = GPIO_PIN_12;
    GPIO_InitStruct.Mode  = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* CAN1 RX: PA11 -> Input Floating (or pull-up per transceiver design) */
    GPIO_InitStruct.Pin  = GPIO_PIN_11;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

/* =========================================================================
 * CAN1 Initialization - 500 kbps, standard 11-bit ID
 * APB1 = 36 MHz. Bit time = (1 + BS1 + BS2) * Tq
 * Prescaler=4 -> Tq = 4/36MHz = 111.11ns
 * BS1=15Tq, BS2=2Tq -> bit = 18Tq = 2.0us -> 500 kHz = 500 kbps  (correct)
 * Sample point = (1+15)/18 = 88.9% (good practice for automotive CAN)
 * ========================================================================= */
static void MX_CAN1_Init(void)
{
    hcan1.Instance = CAN1;
    hcan1.Init.Prescaler          = 4;
    hcan1.Init.Mode                = CAN_MODE_NORMAL;
    hcan1.Init.SJW                 = CAN_SJW_1TQ;
    hcan1.Init.BS1                 = CAN_BS1_15TQ;
    hcan1.Init.BS2                 = CAN_BS2_2TQ;
    hcan1.Init.TTCM                = DISABLE;
    hcan1.Init.ABOM                = ENABLE;   /* auto bus-off management */
    hcan1.Init.AWUM                = DISABLE;
    hcan1.Init.NART                = DISABLE;  /* auto-retransmit on error */
    hcan1.Init.RFLM                = DISABLE;
    hcan1.Init.TXFP                = ENABLE;   /* TX priority by request order (FIFO) */

    if (HAL_CAN_Init(&hcan1) != HAL_OK)
    {
        Error_Handler();
    }

    HAL_NVIC_SetPriority(CAN1_RX0_IRQn, 1, 0);
    HAL_NVIC_EnableIRQ(CAN1_RX0_IRQn);
}

/* =========================================================================
 * TIM2 Initialization - PWM for Servo1-4 (CH1-CH4)
 * 72MHz timer clock (APB1 x2 since APB1 prescaler != 1)
 * Prescaler = 71  -> 1 MHz counter (1 us/tick)
 * Period (ARR) = 19999 -> 20 ms frame (50 Hz servo refresh)
 * ========================================================================= */
static void MX_TIM2_Init(void)
{
    TIM_OC_InitTypeDef sConfigOC = {0};

    htim2.Instance               = TIM2;
    htim2.Init.Prescaler         = 71;      /* 72MHz/(71+1) = 1MHz */
    htim2.Init.CounterMode       = TIM_COUNTERMODE_UP;
    htim2.Init.Period            = 19999;   /* 1MHz/(19999+1) = 50Hz -> 20ms */
    htim2.Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;
    htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;

    if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
    {
        Error_Handler();
    }

    sConfigOC.OCMode     = TIM_OCMODE_PWM1;
    sConfigOC.Pulse       = 500;  /* default 0 deg = 500us */
    sConfigOC.OCPolarity  = TIM_OCPOLARITY_HIGH;
    sConfigOC.OCFastMode  = TIM_OCFAST_DISABLE;

    if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK) { Error_Handler(); }
    if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_2) != HAL_OK) { Error_Handler(); }
    if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_3) != HAL_OK) { Error_Handler(); }
    if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_4) != HAL_OK) { Error_Handler(); }
}

/* =========================================================================
 * TIM3 Initialization - PWM for Servo5 (CH1)
 * Same 1MHz / 20ms configuration as TIM2
 * ========================================================================= */
static void MX_TIM3_Init(void)
{
    TIM_OC_InitTypeDef sConfigOC = {0};

    htim3.Instance               = TIM3;
    htim3.Init.Prescaler         = 71;
    htim3.Init.CounterMode       = TIM_COUNTERMODE_UP;
    htim3.Init.Period            = 19999;
    htim3.Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;
    htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;

    if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
    {
        Error_Handler();
    }

    sConfigOC.OCMode     = TIM_OCMODE_PWM1;
    sConfigOC.Pulse       = 500;
    sConfigOC.OCPolarity  = TIM_OCPOLARITY_HIGH;
    sConfigOC.OCFastMode  = TIM_OCFAST_DISABLE;

    if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK) { Error_Handler(); }
}

/* =========================================================================
 * MSP init hooks - enable peripheral clocks (normally CubeMX-generated
 * in stm32f1xx_hal_msp.c; included here for completeness)
 * ========================================================================= */
void HAL_CAN_MspInit(CAN_HandleTypeDef *hcan)
{
    if (hcan->Instance == CAN1)
    {
        __HAL_RCC_CAN1_CLK_ENABLE();
    }
}

void HAL_TIM_PWM_MspInit(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM2)
    {
        __HAL_RCC_TIM2_CLK_ENABLE();
    }
    else if (htim->Instance == TIM3)
    {
        __HAL_RCC_TIM3_CLK_ENABLE();
    }
}

/* =========================================================================
 * IRQ Handler - must also be declared in stm32f1xx_it.c
 * ========================================================================= */
void CAN1_RX0_IRQHandler(void)
{
    HAL_CAN_IRQHandler(&hcan1);
}

/* =========================================================================
 * Error handler
 * ========================================================================= */
static void Error_Handler(void)
{
    __disable_irq();
    while (1)
    {
        /* Trap - attach debugger or watch an LED here */
    }
}
