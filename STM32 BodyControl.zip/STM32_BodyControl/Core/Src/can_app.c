/**
 ******************************************************************************
 * @file    can_app.c
 * @brief   CAN application layer implementation for STM32F103
 ******************************************************************************
 */

#include <string.h>
#include "can_app.h"
#include "servo.h"

/* =========================================================================
 * Private data
 * ========================================================================= */
static CAN_HandleTypeDef *s_hcan = NULL;

static BCM_LightRainCmd_t s_lastCmd = {0};
static volatile uint32_t s_lastRxTick = 0;
static volatile bool s_rxAlive = false;

static uint32_t s_lastTxTick = 0;

/* Current servo feedback shadow (updated after every apply) */
static STM32_ServoStatus_t s_servoStatus = {0};

/* =========================================================================
 * Private helpers
 * ========================================================================= */

/**
 * @brief  Configure CAN filter to accept only 0x320 (BCM_LightRainCmd).
 *         Uses filter bank 0, mask mode, standard 11-bit ID, FIFO0.
 */
static void CANApp_ConfigFilter(CAN_HandleTypeDef *hcan)
{
    CAN_FilterTypeDef filter;

    /* Standard ID filter for 0x320 exact match (mask = all bits care) */
    uint32_t id  = CAN_ID_BCM_LIGHTRAINCMD << 5;  /* STDID in bits [31:21] for 32-bit filter reg layout used by HAL (left-aligned) */
    uint32_t mask = 0x7FFU << 5;                  /* match all 11 ID bits  */

    filter.FilterIdHigh         = (uint16_t)(id >> 16);
    filter.FilterIdLow          = (uint16_t)(id & 0xFFFF);
    filter.FilterMaskIdHigh     = (uint16_t)(mask >> 16);
    filter.FilterMaskIdLow      = (uint16_t)(mask & 0xFFFF);
    filter.FilterFIFOAssignment = CAN_RX_FIFO0;
    filter.FilterBank           = 0;
    filter.FilterMode           = CAN_FILTERMODE_IDMASK;
    filter.FilterScale          = CAN_FILTERSCALE_32BIT;
    filter.FilterActivation     = ENABLE;
    filter.SlaveStartFilterBank = 14; /* only relevant for dual-CAN parts; harmless on single-CAN F103 */

    HAL_CAN_ConfigFilter(hcan, &filter);
}

/**
 * @brief  Decode raw 8-byte payload of BCM_LightRainCmd into struct,
 *         then apply directly to the 5 servos.
 */
static void CANApp_DecodeAndApply(const uint8_t *data)
{
    s_lastCmd.HighLowBeam_Cmd   = DBC_GET_HIGHLOWBEAM(data);
    s_lastCmd.TurnSignal_Cmd    = DBC_GET_TURNSIGNAL(data);
    s_lastCmd.FlashLight_Cmd    = DBC_GET_FLASHLIGHT(data);
    s_lastCmd.WiperSpeed_Cmd    = DBC_GET_WIPERSPEED(data);
    s_lastCmd.WiperWasher_Cmd   = DBC_GET_WIPERWASHER(data);
    s_lastCmd.HeadlightMode_Cmd = DBC_GET_HEADLIGHTMODE(data);

    Servo_ApplyHighLowBeam((uint8_t)s_lastCmd.HighLowBeam_Cmd);
    Servo_ApplyTurnSignal((uint8_t)s_lastCmd.TurnSignal_Cmd);
    Servo_ApplyWiperSpeed((uint8_t)s_lastCmd.WiperSpeed_Cmd);
    Servo_ApplyWiperWasher((uint8_t)s_lastCmd.WiperWasher_Cmd);
    Servo_ApplyHeadlightMode((uint8_t)s_lastCmd.HeadlightMode_Cmd);

    /* NOTE: FlashLight_Cmd (0=Normal,1=Flash) is a momentary/boolean
     * behaviour layered on top of HighLowBeam_Cmd. If your hardware needs
     * a blink pattern rather than a static position, handle it in
     * CANApp_Task() using a toggle timer instead of here. */
}

/**
 * @brief  Read current servo positions and build the TX payload for
 *         STM32_ServoStatus (0x325).
 */
static void CANApp_BuildServoStatus(uint8_t *txData)
{
    s_servoStatus.Servo1_HighLow_Pos   = Servo_GetDegree(SERVO_1_HIGHLOW);
    s_servoStatus.Servo2_Turn_Pos      = Servo_GetDegree(SERVO_2_TURN);
    s_servoStatus.Servo3_Wiper_Pos     = Servo_GetDegree(SERVO_3_WIPER);
    s_servoStatus.Servo4_Washer_Pos    = Servo_GetDegree(SERVO_4_WASHER);
    s_servoStatus.Servo5_Headlight_Pos = Servo_GetDegree(SERVO_5_HEADLIGHT);

    DBC_PACK_SERVOSTAT(txData,
                        s_servoStatus.Servo1_HighLow_Pos,
                        s_servoStatus.Servo2_Turn_Pos,
                        s_servoStatus.Servo3_Wiper_Pos,
                        s_servoStatus.Servo4_Washer_Pos,
                        s_servoStatus.Servo5_Headlight_Pos);
}

/**
 * @brief  Transmit STM32_ServoStatus (0x325) using next free TX mailbox.
 */
static void CANApp_SendServoStatus(void)
{
    CAN_TxHeaderTypeDef txHeader;
    uint8_t txData[8];
    uint32_t txMailbox;

    txHeader.StdId              = CAN_ID_STM32_SERVOSTAT;
    txHeader.ExtId               = 0;
    txHeader.IDE                 = CAN_ID_STD;
    txHeader.RTR                 = CAN_RTR_DATA;
    txHeader.DLC                 = 8;
    txHeader.TransmitGlobalTime  = DISABLE;

    CANApp_BuildServoStatus(txData);

    if (HAL_CAN_GetTxMailboxesFreeLevel(s_hcan) > 0) {
        HAL_CAN_AddTxMessage(s_hcan, &txHeader, txData, &txMailbox);
    }
    /* If all mailboxes are busy, this cycle is skipped; next 100ms tick
     * will retry. This keeps the task non-blocking. */
}

/* =========================================================================
 * Public API
 * ========================================================================= */

void CANApp_Init(CAN_HandleTypeDef *hcan)
{
    s_hcan = hcan;

    CANApp_ConfigFilter(hcan);

    HAL_CAN_Start(hcan);
    HAL_CAN_ActivateNotification(hcan, CAN_IT_RX_FIFO0_MSG_PENDING);

    s_lastTxTick = HAL_GetTick();
    s_lastRxTick = HAL_GetTick();
    s_rxAlive = false;

    memset(&s_lastCmd, 0, sizeof(s_lastCmd));
    memset(&s_servoStatus, 0, sizeof(s_servoStatus));
}

void CANApp_RxFifo0Callback(CAN_HandleTypeDef *hcan)
{
    CAN_RxHeaderTypeDef rxHeader;
    uint8_t rxData[8];

    if (HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rxHeader, rxData) != HAL_OK) {
        return;
    }

    if (rxHeader.IDE != CAN_ID_STD) {
        return; /* only standard 11-bit IDs expected on this network */
    }

    if (rxHeader.StdId == CAN_ID_BCM_LIGHTRAINCMD && rxHeader.DLC == 8U) {
        CANApp_DecodeAndApply(rxData);
        s_lastRxTick = HAL_GetTick();
        s_rxAlive = true;
    }
}

void CANApp_Task(void)
{
    uint32_t now = HAL_GetTick();

    /* Cyclic TX every CAN_CYCLE_SERVOSTAT_MS (100ms) */
    if ((now - s_lastTxTick) >= CAN_CYCLE_SERVOSTAT_MS) {
        s_lastTxTick = now;
        CANApp_SendServoStatus();
    }

    /* RX timeout monitor */
    if (s_rxAlive && ((now - s_lastRxTick) > CAN_RX_TIMEOUT_MS)) {
        s_rxAlive = false;
        /* Optional: define fail-safe servo behaviour on comm loss.
         * Example - hold last position (default) or force all to 0:
         *
         * Servo_ApplyHighLowBeam(0);
         * Servo_ApplyTurnSignal(0);
         * Servo_ApplyWiperSpeed(0);
         * Servo_ApplyWiperWasher(0);
         * Servo_ApplyHeadlightMode(0);
         */
    }
}

bool CANApp_IsRxAlive(void)
{
    return s_rxAlive;
}

const BCM_LightRainCmd_t *CANApp_GetLastCmd(void)
{
    return &s_lastCmd;
}
