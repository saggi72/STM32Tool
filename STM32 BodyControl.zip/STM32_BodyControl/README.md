# STM32F103 Body Control Slave (STM32Tool)

Firmware cho node **STM32Tool** trong mạng `VehicleBodyCAN` (500 kbps),
sinh ra từ `BodyControlNetwork.dbc`.

## 1. Chức năng

- **Nhận** message `BCM_LightRainCmd` (ID `0x320`, DLC 8, chu kỳ 50ms) từ `ControlECU`
  → giải mã 6 tín hiệu điều khiển → lái 5 servo qua PWM.
- **Gửi** message `STM32_ServoStatus` (ID `0x325`, DLC 8, chu kỳ 100ms) về `ControlECU`
  → phản hồi vị trí hiện tại (độ, 0–180) của 5 servo.

## 2. Cấu trúc thư mục

```
STM32_BodyControl/
└── Core/
    ├── Inc/
    │   ├── can_dbc.h    # Định nghĩa ID, enum, macro giải mã/đóng gói theo DBC
    │   ├── servo.h       # API điều khiển servo
    │   └── can_app.h     # API tầng ứng dụng CAN
    └── Src/
        ├── main.c        # Khởi tạo clock/GPIO/TIM/CAN, vòng lặp chính
        ├── servo.c        # Driver PWM cho 5 servo (TIM2 CH1-4, TIM3 CH1)
        └── can_app.c      # Xử lý RX/TX CAN, filter, timeout
```

## 3. Sơ đồ đấu nối phần cứng

| Tín hiệu               | Chân MCU | Timer/Channel |
|-------------------------|----------|----------------|
| Servo1_HighLow_Pos      | PA0      | TIM2 CH1       |
| Servo2_Turn_Pos         | PA1      | TIM2 CH2       |
| Servo3_Wiper_Pos        | PA2      | TIM2 CH3       |
| Servo4_Washer_Pos       | PA3      | TIM2 CH4       |
| Servo5_Headlight_Pos    | PA6      | TIM3 CH1       |
| CAN_RX                  | PA11     | CAN1           |
| CAN_TX                  | PA12     | CAN1           |

> CAN1 trên STM32F103 cần **transceiver ngoài** (ví dụ TJA1050, SN65HVD230) nối
> giữa PA11/PA12 và bus CAN_H/CAN_L. Có điện trở terminator 120Ω hai đầu bus.

**Xung PWM servo tiêu chuẩn (50Hz, RC servo hobby):**
- 0°   → 500 µs
- 90°  → 1500 µs
- 180° → 2500 µs

## 4. Bảng ánh xạ tín hiệu DBC → Servo

| Tín hiệu DBC          | Giá trị | Servo   | Góc (độ) |
|------------------------|---------|---------|----------|
| HighLowBeam_Cmd        | 0 OFF   | Servo1  | 0        |
|                         | 1 Low   | Servo1  | 90       |
|                         | 2 High  | Servo1  | 180      |
| TurnSignal_Cmd         | 0 OFF   | Servo2  | 90 (giữa)|
|                         | 1 LEFT  | Servo2  | 30       |
|                         | 2 RIGHT | Servo2  | 150      |
|                         | 3 HAZARD| Servo2  | 90       |
| WiperSpeed_Cmd         | 0 OFF   | Servo3  | 0        |
|                         | 1 INT1  | Servo3  | 36       |
|                         | 2 INT2  | Servo3  | 72       |
|                         | 3 LOW   | Servo3  | 108      |
|                         | 4 HIGH  | Servo3  | 180      |
| WiperWasher_Cmd        | 0 OFF   | Servo4  | 0        |
|                         | 1 ACTIVE| Servo4  | 90       |
| HeadlightMode_Cmd      | 0 OFF   | Servo5  | 0        |
|                         | 1 AUTO  | Servo5  | 60       |
|                         | 2 FOG   | Servo5  | 120      |
|                         | 3 FOLD  | Servo5  | 180      |

> Các giá trị góc trong `servo.h` (`SERVOx_POS_*`) chỉ là **giá trị mặc định
> gợi ý** — chỉnh lại theo cơ cấu servo thực tế của bạn.

`FlashLight_Cmd` (0=Normal, 1=Flash) hiện **chưa** điều khiển servo — đây là
tín hiệu dạng nhấp nháy tạm thời. Nếu cần hiệu ứng nhấp nháy thật, xử lý nó
bằng timer riêng trong `CANApp_Task()` thay vì set vị trí tĩnh.

## 5. Cấu hình Clock & CAN Bit Timing

- HSE 8 MHz → PLL x9 → **SYSCLK 72 MHz**
- APB1 = 36 MHz (nguồn clock cho CAN1 và TIM2/TIM3 trước khi x2 nội bộ)
- CAN1 bit timing cho **500 kbps**:
  - Prescaler = 4
  - BS1 = 15 Tq, BS2 = 2 Tq, SJW = 1 Tq
  - Tổng = 1 + 15 + 2 = 18 Tq/bit
  - Tq = 4 / 36MHz = 111.1 ns → bit time = 18 × 111.1ns = 2.0 µs → **500 kHz ✓**
  - Sample point ≈ 88.9% (chuẩn automotive)

⚠️ **Kiểm tra lại bit timing nếu bạn dùng CubeMX**: giá trị Prescaler/BS1/BS2
phụ thuộc đúng vào tần số APB1 thực tế của project bạn generate. Dùng công cụ
"Bit timing calculator" trong CubeMX để double-check trước khi build.

## 6. Build

Project này viết theo phong cách code sinh từ **STM32CubeMX (HAL Driver)**.
Cách dùng nhanh nhất:

1. Mở STM32CubeMX, tạo project mới cho **STM32F103C8Tx**.
2. Bật **CAN1** (mode: Normal), **TIM2** (PWM CH1-CH4), **TIM3** (PWM CH1).
3. Cấu hình Clock: HSE 8MHz, SYSCLK 72MHz (theo mục 5).
4. Generate code (Toolchain: Keil MDK-ARM / STM32CubeIDE / Makefile tùy bạn).
5. Copy đè 3 file trong `Core/Src/` (`main.c`, `servo.c`, `can_app.c`) và
   3 file trong `Core/Inc/` (`can_dbc.h`, `servo.h`, `can_app.h`) vào project.
6. Thêm khai báo `void CAN1_RX0_IRQHandler(void);` vào `stm32f1xx_it.c` nếu
   CubeMX chưa tự sinh (thường đã có sẵn — chỉ cần đảm bảo nó gọi
   `HAL_CAN_IRQHandler(&hcan1)`).
7. Build & flash bằng ST-Link.

## 7. Test nhanh bằng CANoe/TSMaster

Import `BodyControlNetwork.dbc`, gửi message `BCM_LightRainCmd` (0x320) với
`WiperSpeed_Cmd = 4` (HIGH) → quan sát `STM32_ServoStatus` (0x325) phản hồi
`Servo3_Wiper_Pos = 180` sau tối đa 100ms.
